export interface Shipping {
  id: number
  shippingId: string
  name_shipping: string
}
