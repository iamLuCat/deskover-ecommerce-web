export class StorageConstants {
  static readonly TOKEN = 'token';
  static readonly USER_INFO = 'userInfo';
}
