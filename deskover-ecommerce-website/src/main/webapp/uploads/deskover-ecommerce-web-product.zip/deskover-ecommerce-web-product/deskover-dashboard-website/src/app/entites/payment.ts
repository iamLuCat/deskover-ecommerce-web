export interface Payment {
  id: number
  payment_id: string
  name_payment: string
}
