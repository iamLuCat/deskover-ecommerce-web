import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flash-sales',
  templateUrl: './flash-sales.component.html',
  styleUrls: ['./flash-sales.component.scss']
})
export class FlashSalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
