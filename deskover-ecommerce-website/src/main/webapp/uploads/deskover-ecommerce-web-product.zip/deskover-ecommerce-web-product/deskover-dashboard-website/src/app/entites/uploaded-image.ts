export class UploadedImage {
  url: string
  filename: string
}
