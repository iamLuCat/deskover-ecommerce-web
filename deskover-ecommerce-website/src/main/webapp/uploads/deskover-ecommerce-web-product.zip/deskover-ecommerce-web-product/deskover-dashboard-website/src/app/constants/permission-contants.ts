export class PermissionContants {
  static readonly ALL = 'ROLE_ALL';
  static readonly ADMIN = 'ROLE_ADMIN';
  static readonly SHIPPER = 'ROLE_SHIPPER';
  static readonly MANAGER = 'ROLE_MANAGER';
  static readonly SELLER = 'ROLE_SELLER';
}
