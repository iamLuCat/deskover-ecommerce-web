export interface DatatablesResponse {
  data: any[]
  draw: number
  recordsFiltered: number
  recordsTotal: number
}
