package com.deskover.model.entity.dto;

public class UserDTO {
	private String username;
	private String fullname;
	private String avatar;
}
